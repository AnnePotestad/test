package com.example.demo;

import org.springframework.data.rest.core.annotation.HandleAfterCreate;
import org.springframework.data.rest.core.annotation.HandleBeforeCreate;
import org.springframework.data.rest.core.annotation.RepositoryEventHandler;
import org.springframework.stereotype.Component;

@Component
@RepositoryEventHandler(Products.class)
public class ProductEventHandler {
	@HandleBeforeCreate
	public void beforeCreate(Products products) {
		System.out.println("Are you sure you want to delete?");
	}
	
	@HandleAfterCreate
	public void afterCreate(Products products) {
		System.out.println("Successfully deleted!");
	}
}
