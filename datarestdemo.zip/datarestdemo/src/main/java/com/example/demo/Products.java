package com.example.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Products")
public class Products {
	@Id // galing sa JPA
	@GeneratedValue(strategy = GenerationType.IDENTITY) // To have auto generated id
	@Column(name="product_id")
	private long id;
	
	@Column(name="product_name")
	private String name;
	
	@Column(name="product_desc")
	private String description;
	
	@Column(name="product_price")
	private float price;
	
	@Column(name="product_stocks")
	private int stocks;
	
	@Column(name="product_branch")
	private String branch;
	
	public Products() {
		super();
	}

	public Products(long id, String name, String description, float price, int stocks, String branch) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.price = price;
		this.stocks = stocks;
		this.branch = branch;
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public float getPrice() {
		return price;
	}

	public int getStocks() {
		return stocks;
	}

	public String getBranch() {
		return branch;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public void setStocks(int stocks) {
		this.stocks = stocks;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}
	
	
	
	
	
}
